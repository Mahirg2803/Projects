transportation = ['car','train','bike']
print("If it's hot and sunny, I like to ride the " + transportation[2] +".")
print("If I need to transport something heavy and big I use the" + transportation[0]+".")
print("Using the " +transportation[1]+ " instead of the " +transportation[0] + " saves the environment.")