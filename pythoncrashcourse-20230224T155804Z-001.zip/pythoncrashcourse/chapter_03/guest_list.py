guest_list = ['Artistotle','Sartre','Epictetus']
for guest in guest_list:
    print("Hello " +guest+ ". I would like to invite you to dinner.")

#Alternate/ "simpler" version
#print("Hello " + guest_list[0] +". I would like to invite you to dinner.")
#print("Hello " + guest_list[1] +". I would like to invite you to dinner.")
#print("Hello " + guest_list[2] +". I would like to invite you to dinner.")