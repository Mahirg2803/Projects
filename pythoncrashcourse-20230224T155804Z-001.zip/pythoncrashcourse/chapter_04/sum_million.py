numbers = [i for i in range(1,1000001)]
print(min(numbers))
print(max(numbers))
print(sum(numbers))
