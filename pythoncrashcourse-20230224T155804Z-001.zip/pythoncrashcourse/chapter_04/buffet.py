food = ('potatoe salad','noodles','turkey','caesar salad','pork')
for f in food:
    print(f)
food = ('potatoe salad','soup','lasagna','caesar salad','pork')
for f in food:
    print(f)
