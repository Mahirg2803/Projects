animals = ['termites','bees','ants']
for animal in animals:
    print(animal + " build nests.")
print("Don't mess with those!")
