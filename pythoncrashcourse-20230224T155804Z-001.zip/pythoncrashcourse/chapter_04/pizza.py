pizzas = ['salami','peperoni','pineapple']
for pizza in pizzas:
    print(pizza)