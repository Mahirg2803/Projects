mulitple_three = [i*3 for i in range(1,11)]
for number in mulitple_three:
    print(number)
