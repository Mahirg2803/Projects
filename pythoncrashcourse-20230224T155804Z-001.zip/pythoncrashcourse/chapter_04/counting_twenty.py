numbers = [i for i in range(1,21)]
for number in numbers:
    print(number)
