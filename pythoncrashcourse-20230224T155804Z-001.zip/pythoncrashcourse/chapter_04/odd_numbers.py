numbers = list(filter(lambda x: x % 2 ==1,list(range(1,21))))
#numbers = list(range(1,21,2))
for number in numbers:
    print(number)