cubes = list(map(lambda x: x*x*x,list(range(1,11))))
for cube in cubes:
    print(cube)
