numbers = [i for i in range(1,1000001)]
for x in numbers:
    print(x)