print("What is your name?")
name = "Arthur"
print("It is " + name + " King of the Britons!")
