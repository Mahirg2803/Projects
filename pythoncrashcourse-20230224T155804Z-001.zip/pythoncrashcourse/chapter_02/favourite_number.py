favourite_number = 7
#uses String concatenation and casting to print string
print("My favourite number is: " +str(favourite_number))