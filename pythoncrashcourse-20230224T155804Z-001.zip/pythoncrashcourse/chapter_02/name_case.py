name = "brian"
print(name.lower())
print(name.upper())
print(name.title())