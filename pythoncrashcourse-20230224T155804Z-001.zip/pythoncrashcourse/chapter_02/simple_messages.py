message = "Black Knight: Tis but a scratch."
print(message)

message = "King Arthur: A scratch? Your arm's off!"
print(message)
