name = "\t Arthur Dent \n"
print(name.lstrip())
print(name.rstrip())
print(name.strip())