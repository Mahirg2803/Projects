message = "Nobody expects the Spanish Inquisition!"
print(message)
