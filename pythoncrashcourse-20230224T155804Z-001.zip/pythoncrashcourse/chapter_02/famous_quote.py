quote = '''\
    Ford Prefect once said:" The Guide says there is an
    art to flying or rather a knack. The knack lies in 
    learning how to throw yourself at the ground and miss."'''

print(quote)
        
