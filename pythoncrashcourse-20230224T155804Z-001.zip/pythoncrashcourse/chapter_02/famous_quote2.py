famous_device = "The guide"
print(famous_device + ' once said: "Don\'t panic"')