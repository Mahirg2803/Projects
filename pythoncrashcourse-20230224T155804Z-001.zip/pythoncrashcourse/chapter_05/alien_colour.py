def is_green(alien_colour):
    return alien_colour == 'green'

alien_colour = 'yellow'
print(is_green(alien_colour))
alien_colour = 'green'
print(is_green(alien_colour))
