def points(alien_colour):
    return 5 if alien_colour == 'green' else 10
print(points('green'))
print(points('yellow'))
