#Only two tests
flower = 'rose'
print("Is flower == 'rose'? I say true")
print(flower== 'rose')

print("Is flower.upper() == 'rose'? I say false")
print(flower.upper() == 'rose')

