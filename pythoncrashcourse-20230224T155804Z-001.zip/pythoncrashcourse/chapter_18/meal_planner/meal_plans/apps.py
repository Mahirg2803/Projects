from django.apps import AppConfig


class MealPlansConfig(AppConfig):
    name = 'meal_plans'
