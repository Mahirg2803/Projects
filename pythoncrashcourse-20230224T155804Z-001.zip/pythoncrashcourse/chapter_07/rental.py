car_type = input("What kind of car do you want?: ")
print("Let me see if I can find a " + car_type + '.')
