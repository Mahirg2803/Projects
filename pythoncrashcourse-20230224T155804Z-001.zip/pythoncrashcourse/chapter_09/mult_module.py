from admin_module import Admin

admin = Admin('Foo','Bar',['add users'])
admin.show_privileges()
