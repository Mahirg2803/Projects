from restaurant import Restaurant

# prints the output from restaurant aswell   
restaurant = Restaurant('foo','bar')
restaurant.describe_restaurant()
