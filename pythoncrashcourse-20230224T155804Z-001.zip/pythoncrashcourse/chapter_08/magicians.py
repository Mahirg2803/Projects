def show_magicians(magicians):
    for magician in magicians:
        print(magician)
magicians = ['merlin','gandalf','voldemort']
show_magicians(magicians)

