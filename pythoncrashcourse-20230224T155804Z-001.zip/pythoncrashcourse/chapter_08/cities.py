def city_country(name,country):
    return name.title() + ', '+ country.title()
print(city_country('Singapore','Singapore'))
print(city_country('Casblanca','Morocco'))
print(city_country('Kolkata','India'))
