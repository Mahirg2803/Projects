def print_book(title):
    print("One of my favourite books is " + title)

print_book("Catch 22")