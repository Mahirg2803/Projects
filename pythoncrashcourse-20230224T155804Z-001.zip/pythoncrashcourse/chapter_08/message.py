def display_message():
    print("In this chapter functions are introduced.")

display_message()