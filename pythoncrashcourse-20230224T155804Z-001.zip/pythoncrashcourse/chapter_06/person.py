person_dict = {'first_name' : 'john', 'last_name' : 'smith', 'age':'33','city' : 'New Orleans',}
print('His name is ' + person_dict['first_name'] +' ' +  person_dict['last_name'])
print("He's " + person_dict['age'] +" years old and lives in " + person_dict['city'])

