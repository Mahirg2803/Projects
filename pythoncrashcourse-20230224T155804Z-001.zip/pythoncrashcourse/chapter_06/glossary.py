#Only five words

glossary = {'dict' : 'map', 'python' : 'interpreted programming language',
            'print':'function that prints to stdout',"':'":'no {,} necessary!'
            ,'list':'data structure'}
for word, meaning in glossary.items():
    print("Word:",word,"Meaning:",meaning)
